注意：在转换onnx -> rknn模型时候，使用1.4左右版本的转换库

配置环境：
sudo cp package/librknn_api.so package/librknnrt.so /usr/lib
sudo pip3 install package/rknn_toolkit_lite2-1.4.0-cp37-cp37m-linux_aarch64.whl

修改相关参数：
launch/detect.launch
script/cfg.py
script/utils.py 中的tranform函数

相关脚本:
overclock.sh 超频
pwm_fan.sh   持续开启最高级风扇
rkcat.sh     查看NPU和CPU温度
