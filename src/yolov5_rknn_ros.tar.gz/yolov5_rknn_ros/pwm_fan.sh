#!/bin/bash

HWMON_DIR="/sys/class/hwmon/hwmon8"

# 启用PWM控制 (如果有需要)
if [ -f $HWMON_DIR/pwm1_enable ]; then
    echo 1 | sudo tee $HWMON_DIR/pwm1_enable
fi

# 持续设置风扇转速
while true; do
    echo 255 | sudo tee $HWMON_DIR/pwm1
    sleep 0.1
done
