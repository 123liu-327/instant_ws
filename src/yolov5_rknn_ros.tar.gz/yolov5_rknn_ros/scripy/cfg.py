import pathlib
current_dir = pathlib.Path(__file__).parent

RKNN_MODEL = str(current_dir / '..' / 'models' / 'data_2_0501_11_02_0528.rknn')
CLASSES = [
    "0_cola", 
    "1_cake", 
    "2_milk", 
    "3_banana", 
    "4_apple", 
    "5_watermelon", 
    "6_pepper", 
    "7_tomato", 
    "8_potato", 
    "9_green", 
    "10_red"
]

OBJ_THRESH = 0.25
NMS_THRESH = 0.45
IMG_SIZE = 640

INPUT_IMAGE_TOPIC = '/usb_cam/image_raw'
OUTPUT_TOPIC = '/detect_results'

OUTPUT_DRAW_IMG_TOPIC = '/detect_draw_image'
SHOW_DRAW_IMG = False