#!/usr/bin/env python3
#coding=utf-8


import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from yolov5_rknn_ros.msg import DetectResult, DetectResults
from cv_bridge import CvBridge, CvBridgeError
from cfg import *


class ObjectDetectNode:
    def __init__(self):

        rospy.init_node('object_detect_node')

        self.input_topic = INPUT_IMAGE_TOPIC
        self.output_topic = OUTPUT_TOPIC
        self.classes = CLASSES
        self.show_draw_img = SHOW_DRAW_IMG
        self.bridge = CvBridge()
 
        self.image_sub = rospy.Subscriber(self.input_topic, Image, self.image_callback, queue_size=5)
        self.detect_pub = rospy.Publisher(self.output_topic, DetectResults, queue_size=5)
        self.draw_img_pub = rospy.Publisher(OUTPUT_DRAW_IMG_TOPIC, Image, queue_size=5)
    
        from utils import interface
        self.my_interface = interface


    def get_results_and_draw_img(self, image, boxes, scores, classes):

        if boxes is None:
            # print('No object detected')
            return None, image
        

        
        DetectResults_msg = DetectResults(
            header=rospy.Header(stamp=rospy.Time.now()),
            results=[]
        )



        for box, score, cl in zip(boxes, scores, classes):
            # ???? 为什么？？？？
            # top, left, right, bottom = box 
            left, top, right, bottom = int(box[0]), int(box[1]), int(box[2]), int(box[3])

            DetectResults_msg.results.append(DetectResult(
                id=cl,
                label=self.classes[cl],
                confidence=score,
                bbox=[top, left, right, bottom]
            ))
            print(f"label: {self.classes[cl]}, score: {score:.2f},  top: {top},left: {left}, right: {right},  bottom: {bottom}")


            if self.show_draw_img:
                # cv2.rectangle(image, (top, left), (right, bottom), (255, 0, 0), 2)
                cv2.rectangle(image, (left, top), (right, bottom), (255, 0, 0), 2)
                cv2.putText(image, '{0} {1:.2f}'.format(self.classes[cl], score),
                            # (top, left - 6),
                            (left, top - 6),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (0, 0, 255), 2)


                center_x = (left + right) // 2
                center_y = (top + bottom) // 2
                cv2.circle(image, (center_x, center_y), 5, (0, 0, 255), -1)  # 绘制实心圆，半径设为 5，颜色为红色 (0, 0, 255)
        


        return DetectResults_msg, image
    

    def image_callback(self, msg):
        try:

            img = self.bridge.imgmsg_to_cv2(msg, "bgr8")  # ros_image -> cv2_image
            img = cv2.flip(img, 1)  # 水平翻转图像，抵消镜像


            img, boxes, classes, scores = self.my_interface(img)  # 推理
            results, draw_img = self.get_results_and_draw_img(img, boxes, scores, classes)  # 处理


            if results is not None:
                results.header = msg.header
                self.detect_pub.publish(results)

            if self.show_draw_img and draw_img is not None:
                try:
                    draw_img_msg = self.bridge.cv2_to_imgmsg(draw_img, "bgr8")  # cv2_image -> ros_image
                    draw_img_msg.header = msg.header
                    self.draw_img_pub.publish(draw_img_msg)
                except CvBridgeError as e:
                    print(f"draw_img_pub errors : {str(e)}")


        except CvBridgeError as e:
            print(f"image_callback errors : {str(e)}")


if __name__ == '__main__':
    try:
        node = ObjectDetectNode()
        print("--- Starting Object Detect Node ---")

        # 打印关键配置参数
        print("Configuration:")
        print(f"  - RKNN Model: {RKNN_MODEL}")
        print(f"  - Classes: {', '.join(CLASSES)}")
        print(f"  - Confidence Threshold: {OBJ_THRESH:.2f}")
        print(f"  - NMS Threshold: {NMS_THRESH:.2f}")
        print(f"  - Image Size: {IMG_SIZE} x {IMG_SIZE}")
        print(f"  - Input Topic: {INPUT_IMAGE_TOPIC}")
        print(f"  - Output Topic: {OUTPUT_TOPIC}")
        print(f"  - Show Detected Image: {'Enabled' if SHOW_DRAW_IMG else 'Disabled'}")
        

        rospy.spin()
    except rospy.ROSInterruptException:
        pass

